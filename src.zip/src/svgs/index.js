export { default as Sonduck_Logo_1 } from "./7.svg";
export { default as Sonduck_Logo_2 } from "./8.svg";
export { default as Sonduck_Logo_3 } from "./9.svg";
export { default as Sonduck_Logo_4 } from "./10.svg";
export { default as Sonduck_Logo_5 } from "./11.svg";
